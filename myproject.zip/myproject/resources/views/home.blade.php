@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">{{$user->name}} Welcome to Myproject details</div>
                    <div class="panel-body">


                        <form class="form-horizontal" role="form" method="POST" action="{{ url('/details') }}">
                            {{ csrf_field() }}

                            <div class="form-group{{ $errors->has('username') ? ' has-error' : '' }}">
                                <label for="username" class="col-md-4 control-label">Username</label>

                                <div class="col-md-6">
                                    <input id="username" type="text" class="form-control" name="username"
                                           placeholder="{{ $user->name }}" required autofocus>

                                    @if ($errors->has('username'))
                                        <span class="help-block">
                                        <strong>{{ $errors->first('username') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                                <label for="password" class="col-md-4 control-label">Password</label>

                                <div class="col-md-6">
                                    <input id="password" type="password" class="form-control"    name="password" required>

                                    @if ($errors->has('password'))
                                        <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                                <label for="name" class="col-md-4 control-label">Categories</label>

                                <div class="col-md-6">
                                    <div class="dropdown">
                                        <button class="btn btn-default dropdown-toggle btn-block" type="button"
                                                id="menu1" data-toggle="dropdown">
                                            <span class="caret pull-right form-control"></span></button>
                                        <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                            @foreach($categories as $category)
                                                <a href="{{ url('/details/'.$category->id) }}">{{ $category->name }}</a>
                                                <br>
                                            @endforeach

                                        </ul>
                                    </div>
                                </div>

                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                    </div>


                    <div class="form-group">
                        <div class="col-md-8 col-md-offset-4">
                            <button type="submit" class="btn btn-primary">

                                <a href="{{url('/details')}}" style="color: white">Submit</a>
                            </button>

                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
@endsection
